from __future__ import annotations

from pathlib import Path

ROOT = Path.cwd()


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, text: str) -> None:
    (ROOT / path).write_text(text, encoding="utf-8")


def replace_once(path: str, old: str, new: str) -> None:
    text = read(path)
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{path}: expected exactly one match, found {count}: {old[:120]!r}")
    write(path, text.replace(old, new, 1))


def insert_before_once(path: str, marker: str, addition: str) -> None:
    text = read(path)
    count = text.count(marker)
    if count != 1:
        raise RuntimeError(f"{path}: expected exactly one insertion marker, found {count}")
    write(path, text.replace(marker, addition + marker, 1))


# Keep the Android library root in one place and reuse it for camera staging.
replace_once(
    "apps/android/app/src/main/kotlin/com/a2d/notebook/rustbridge/A2dBridge.kt",
    "import android.content.Context\n",
    "import android.content.Context\nimport java.io.File\n",
)
replace_once(
    "apps/android/app/src/main/kotlin/com/a2d/notebook/rustbridge/A2dBridge.kt",
    "object A2dBridge {\n    @Volatile\n",
    "object A2dBridge {\n    fun libraryDirectory(context: Context): File = context.filesDir.resolve(\"library\")\n\n    @Volatile\n",
)
replace_once(
    "apps/android/app/src/main/kotlin/com/a2d/notebook/rustbridge/A2dBridge.kt",
    '            val libraryPath = context.filesDir.resolve("library").absolutePath\n',
    "            val libraryPath = libraryDirectory(context).absolutePath\n",
)

# Allow the capture controller to move from review to a typed accepted scan only after Rust returns.
insert_before_once(
    "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/capture/AutoCaptureStateMachine.kt",
    "    @Synchronized\n    fun continueScanning(\n",
    '''    @Synchronized
    fun reviewRegistrationCompleted(
        token: CaptureRequestToken,
        scanId: String,
    ): AutoCaptureTransition {
        require(scanId.isNotBlank()) { "registered scan ID must not be blank" }
        val review = phase as? AutoCapturePhase.NeedsReview
        if (review == null || review.request.token != token || token.generation != generation) {
            return transition(AutoCaptureEffect.StaleCallbackIgnored("reviewRegistrationCompleted", token))
        }
        phase = AutoCapturePhase.Accepted(review.request, scanId)
        return transition()
    }

''',
)

# Preserve every value required to make the reviewed capture the durable registration request.
state_path = "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/singlepage/SinglePageScannerState.kt"
replace_once(
    state_path,
    "import com.a2d.notebook.rustbridge.EncodedPageAnalysisResult\n",
    "import com.a2d.notebook.rustbridge.EncodedPageAnalysisResult\nimport com.a2d.notebook.rustbridge.EncodedPageRotation\n",
)
replace_once(
    state_path,
    "import uniffi.a2d_ffi.PageResolution\n",
    "import uniffi.a2d_ffi.PageResolution\nimport uniffi.a2d_ffi.RegisteredScan\n",
)
replace_once(
    state_path,
    '''    val captureRequest: AutoCaptureRequest,
    val stagingPath: String,
    val analysis: EncodedPageAnalysisResult,
''',
    '''    val captureRequest: AutoCaptureRequest,
    val stagingPath: String,
    val pageCodePayload: String?,
    val imageRotation: EncodedPageRotation,
    val capturedAtMs: Long,
    val analysis: EncodedPageAnalysisResult,
''',
)
replace_once(
    state_path,
    '''        require(stagingPath.isNotBlank())
        require(pipelineVersion > 0)
''',
    '''        require(stagingPath.isNotBlank())
        require(capturedAtMs > 0L)
        require(!approvalAllowed || !pageCodePayload.isNullOrBlank()) {
            "an approvable review artifact must retain its validated Page Code payload"
        }
        require(pipelineVersion > 0)
''',
)
replace_once(
    state_path,
    '''    val reviewArtifact: SinglePageReviewArtifact? = null,
    val approvedForRegistration: Boolean = false,
    val detailsVisible: Boolean = false,
''',
    '''    val reviewArtifact: SinglePageReviewArtifact? = null,
    val registrationInProgress: Boolean = false,
    val registeredScan: RegisteredScan? = null,
    val detailsVisible: Boolean = false,
''',
)
replace_once(
    state_path,
    "        get() = reviewArtifact?.approvalAllowed == true && !processing\n",
    '''        get() =
            reviewArtifact?.approvalAllowed == true &&
                !processing &&
                !registrationInProgress &&
                registeredScan == null
''',
)

# Pure request construction keeps generated-binding details out of the ViewModel and is JVM-testable.
request_factory_path = ROOT / "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/singlepage/ScanRegistrationRequest.kt"
request_factory_path.write_text(
    '''package com.a2d.notebook.feature.scanner.singlepage

import com.a2d.notebook.rustbridge.AnalyzedPageMarker
import com.a2d.notebook.rustbridge.EncodedPageRotation
import uniffi.a2d_ffi.RegisterScanRequest
import uniffi.a2d_ffi.RegistrationImageFormat
import uniffi.a2d_ffi.RegistrationImageRotation
import uniffi.a2d_ffi.RegistrationMarker
import uniffi.a2d_ffi.ScanCaptureSource

internal fun SinglePageReviewArtifact.toRegisterScanRequest(): RegisterScanRequest {
    require(approvalAllowed) { "blocked review artifacts cannot be registered" }
    val payload = requireNotNull(pageCodePayload?.takeIf(String::isNotBlank)) {
        "validated Page Code payload is required for registration"
    }
    return RegisterScanRequest(
        stagingPath = stagingPath,
        pageCodePayload = payload,
        expectedPageId = captureRequest.pageId,
        activeNotebookId = captureRequest.activeNotebookId,
        captureSource = ScanCaptureSource.CAMERA,
        imageFormat = RegistrationImageFormat.JPEG,
        imageRotation = imageRotation.toRegistrationImageRotation(),
        capturedAtMs = capturedAtMs,
        observedMarkers = analysis.markers.toRegistrationMarkers(),
        previewWarnings = warnings.toRegistrationWarningCodes(),
        userApproved = true,
    )
}

internal fun EncodedPageRotation.toRegistrationImageRotation(): RegistrationImageRotation =
    when (this) {
        EncodedPageRotation.DEGREES_0 -> RegistrationImageRotation.DEGREES0
        EncodedPageRotation.DEGREES_90 -> RegistrationImageRotation.DEGREES90
        EncodedPageRotation.DEGREES_180 -> RegistrationImageRotation.DEGREES180
        EncodedPageRotation.DEGREES_270 -> RegistrationImageRotation.DEGREES270
    }

internal fun List<AnalyzedPageMarker>.toRegistrationMarkers(): List<RegistrationMarker> {
    val markers =
        map { marker ->
            require(marker.id in 0L..UInt.MAX_VALUE.toLong()) {
                "marker ID must fit an unsigned 32-bit integer"
            }
            RegistrationMarker(role = marker.role, id = marker.id.toUInt())
        }
    val roles = markers.map { it.role.trim().uppercase() }
    require(roles.size == 4 && roles.toSet() == setOf("TL", "TR", "BR", "BL")) {
        "registration requires exactly one TL, TR, BR, and BL marker"
    }
    return markers
}

internal fun Set<CapturePolicyWarning>.toRegistrationWarningCodes(): List<String> {
    require(CapturePolicyWarning.MISSING_MARKERS !in this) {
        "a capture with missing markers cannot be approved for registration"
    }
    return map { it.name }.sorted()
}
''',
    encoding="utf-8",
)

# Wire review approval to the generated UniFFI registration method.
vm_path = "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/singlepage/SinglePageScannerViewModel.kt"
replace_once(
    vm_path,
    '''    private var processingJob: Job? = null
    private var processingCancellation: PagePreviewCancellation? = null
    private var pendingStagingFile: File? = null
''',
    '''    private var processingJob: Job? = null
    private var registrationJob: Job? = null
    private var processingCancellation: PagePreviewCancellation? = null
    private var pendingStagingFile: File? = null
    private var pendingCapturedAtMs: Long? = null
''',
)
replace_once(
    vm_path,
    '''                applyTransition(
                    captureMachine.captureSucceeded(
''',
    '''                val capturedAtMs = System.currentTimeMillis()
                pendingCapturedAtMs = capturedAtMs
                applyTransition(
                    captureMachine.captureSucceeded(
''',
)
replace_once(
    vm_path,
    "                startFullResolutionProcessing(request, file)\n",
    "                startFullResolutionProcessing(request, file, capturedAtMs)\n",
)
replace_once(
    vm_path,
    '''                pendingStagingFile?.let(::safeDelete)
                pendingStagingFile = null
                applyTransition(
''',
    '''                pendingStagingFile?.let(::safeDelete)
                pendingStagingFile = null
                pendingCapturedAtMs = null
                applyTransition(
''',
)
replace_once(
    vm_path,
    '''    fun approveReview() {
        val current = mutableState.value
        if (!current.canApprove) {
            update { it.copy(error = "Final page identity must match before approval") }
            return
        }
        update { it.copy(approvedForRegistration = true, error = null) }
    }
''',
    '''    fun approveReview() {
        val current = mutableState.value
        val artifact = current.reviewArtifact
        if (!current.canApprove || artifact == null) {
            update { it.copy(error = "Final page identity must match before registration") }
            return
        }
        check(registrationJob == null) { "scan registration is already active" }
        val generation = current.cameraGeneration
        update { it.copy(registrationInProgress = true, error = null) }
        registrationJob =
            viewModelScope.launch {
                try {
                    val registered =
                        withContext(Dispatchers.IO) {
                            client.registerScan(artifact.toRegisterScanRequest())
                        }
                    if (
                        generation != mutableState.value.cameraGeneration ||
                            mutableState.value.reviewArtifact?.stagingPath != artifact.stagingPath
                    ) {
                        return@launch
                    }
                    pendingStagingFile = null
                    pendingCapturedAtMs = null
                    applyTransition(
                        captureMachine.reviewRegistrationCompleted(
                            artifact.captureRequest.token,
                            registered.scanId,
                        ),
                    )
                    update {
                        it.copy(
                            registrationInProgress = false,
                            registeredScan = registered,
                            capturePhase = captureMachine.snapshot().phase,
                            error = null,
                        )
                    }
                } catch (failure: CancellationException) {
                    throw failure
                } catch (failure: Exception) {
                    update {
                        it.copy(
                            registrationInProgress = false,
                            error = failure.message ?: "Rust scan registration failed",
                        )
                    }
                } finally {
                    registrationJob = null
                }
            }
    }
''',
)
replace_once(
    vm_path,
    '''    fun retake() {
        val artifact = mutableState.value.reviewArtifact ?: return
        safeDelete(File(artifact.stagingPath))
        pendingStagingFile = null
        val transition = captureMachine.continueScanning(System.nanoTime(), true)
        latestAssessment = null
        update {
            it.copy(
                capturePhase = transition.snapshot.phase,
                reviewArtifact = null,
                approvedForRegistration = false,
                detailsVisible = false,
                latestAnalysis = null,
                latestPageResolution = null,
                pageCodeStatus = PageCodeUiStatus.Searching,
                presentation = null,
                error = null,
                cameraGeneration = nextGeneration(it.cameraGeneration),
            )
        }
    }
''',
    '''    fun retake() {
        val current = mutableState.value
        if (current.registrationInProgress) return
        val artifact = current.reviewArtifact ?: return
        val alreadyRegistered = current.registeredScan != null
        if (!alreadyRegistered) {
            safeDelete(File(artifact.stagingPath))
        }
        pendingStagingFile = null
        pendingCapturedAtMs = null
        val transition =
            captureMachine.continueScanning(
                System.nanoTime(),
                allowImmediateSamePageRetake = !alreadyRegistered,
            )
        latestAssessment = null
        update {
            it.copy(
                capturePhase = transition.snapshot.phase,
                reviewArtifact = null,
                registrationInProgress = false,
                registeredScan = null,
                detailsVisible = false,
                latestAnalysis = null,
                latestPageResolution = null,
                pageCodeStatus = PageCodeUiStatus.Searching,
                presentation = null,
                error = null,
                cameraGeneration = nextGeneration(it.cameraGeneration),
            )
        }
    }
''',
)
replace_once(
    vm_path,
    '''    fun leaveScanner() {
        cancelActiveWork(deleteReview = true)
        applyTransition(captureMachine.stop())
        update { it.copy(cameraGeneration = nextGeneration(it.cameraGeneration)) }
    }
''',
    '''    fun leaveScanner() {
        if (mutableState.value.registrationInProgress) {
            update { it.copy(error = "Wait for durable registration to finish before leaving") }
            return
        }
        cancelActiveWork(deleteReview = true)
        applyTransition(captureMachine.stop())
        update { it.copy(cameraGeneration = nextGeneration(it.cameraGeneration)) }
    }
''',
)
replace_once(
    vm_path,
    '''    private fun startFullResolutionProcessing(
        request: AutoCaptureRequest,
        file: File,
    ) {
''',
    '''    private fun startFullResolutionProcessing(
        request: AutoCaptureRequest,
        file: File,
        capturedAtMs: Long,
    ) {
''',
)
replace_once(
    vm_path,
    "                            finishReview(request, file, processed)\n",
    "                            finishReview(request, file, capturedAtMs, processed)\n",
)
replace_once(
    vm_path,
    '''    private suspend fun finishReview(
        request: AutoCaptureRequest,
        file: File,
        processed: PagePreviewProcessingOutcome.Completed,
    ) {
''',
    '''    private suspend fun finishReview(
        request: AutoCaptureRequest,
        file: File,
        capturedAtMs: Long,
        processed: PagePreviewProcessingOutcome.Completed,
    ) {
''',
)
replace_once(
    vm_path,
    '''                captureRequest = request,
                stagingPath = file.absolutePath,
                analysis = result.analysis,
''',
    '''                captureRequest = request,
                stagingPath = file.absolutePath,
                pageCodePayload = finalCode.payload,
                imageRotation = readJpegRotation(file),
                capturedAtMs = capturedAtMs,
                analysis = result.analysis,
''',
)
replace_once(
    vm_path,
    '''                processing = false,
                reviewArtifact = artifact,
                approvedForRegistration = false,
                capturePhase = captureMachine.snapshot().phase,
''',
    '''                processing = false,
                reviewArtifact = artifact,
                registrationInProgress = false,
                registeredScan = null,
                capturePhase = captureMachine.snapshot().phase,
''',
)
replace_once(
    vm_path,
    '''    private data class FinalPageCodeResult(
        val resolution: PageResolution?,
        val warning: String?,
    )
''',
    '''    private data class FinalPageCodeResult(
        val payload: String?,
        val resolution: PageResolution?,
        val warning: String?,
    )
''',
)
replace_once(
    vm_path,
    '''                FinalPageCodeResult(
                    resolution = client.resolvePageCode(payload, request.activeNotebookId),
                    warning = null,
                )
            } catch (_: NotFoundException) {
                FinalPageCodeResult(null, "No Page Code was found in the corrected capture.")
            } catch (failure: Exception) {
                FinalPageCodeResult(
                    null,
                    "Final Page Code validation failed: ${failure.message ?: failure}",
                )
''',
    '''                FinalPageCodeResult(
                    payload = payload,
                    resolution = client.resolvePageCode(payload, request.activeNotebookId),
                    warning = null,
                )
            } catch (_: NotFoundException) {
                FinalPageCodeResult(
                    payload = null,
                    resolution = null,
                    warning = "No Page Code was found in the corrected capture.",
                )
            } catch (failure: Exception) {
                FinalPageCodeResult(
                    payload = null,
                    resolution = null,
                    warning = "Final Page Code validation failed: ${failure.message ?: failure}",
                )
''',
)
replace_once(
    vm_path,
    '''        pendingStagingFile?.let(::safeDelete)
        pendingStagingFile = null
        if (deleteReview) {
''',
    '''        if (registrationJob?.isActive != true) {
            pendingStagingFile?.let(::safeDelete)
            pendingStagingFile = null
            pendingCapturedAtMs = null
        }
        if (deleteReview && registrationJob?.isActive != true) {
''',
)
replace_once(
    vm_path,
    '''    private fun stagingDirectory(): File =
        File(getApplication<Application>().cacheDir, "a2d-scanner-staging")
''',
    '''    private fun stagingDirectory(): File =
        A2dBridge
            .libraryDirectory(getApplication<Application>())
            .resolve("tmp/scanner-staging")
            .also { directory ->
                check(directory.isDirectory || directory.mkdirs()) {
                    "Rust-owned scanner staging directory could not be created"
                }
            }
''',
)

# Do not expose a back/navigation action while a native registration call owns the staging file.
screen_path = "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/singlepage/SinglePageScannerScreen.kt"
replace_once(
    screen_path,
    "import androidx.compose.foundation.layout.Arrangement\n",
    "import androidx.activity.compose.BackHandler\nimport androidx.compose.foundation.layout.Arrangement\n",
)
replace_once(
    screen_path,
    '''    val state by viewModel.state
    val permission = rememberCameraPermissionState()
''',
    '''    val state by viewModel.state
    val permission = rememberCameraPermissionState()
    BackHandler(enabled = state.registrationInProgress) {}
''',
)
replace_once(
    screen_path,
    '''                onBack = {
                    viewModel.leaveScanner()
                    onBack()
                },
''',
    '''                onBack = {
                    if (!state.registrationInProgress) {
                        viewModel.leaveScanner()
                        onBack()
                    }
                },
''',
)

# Replace the old "approved but not saved" presentation with the authoritative Rust result.
content_path = "apps/android/app/src/main/kotlin/com/a2d/notebook/feature/scanner/singlepage/SinglePageScannerContent.kt"
replace_once(
    content_path,
    '    const val APPROVED_NOT_SAVED = "single_scanner_approved_not_saved"\n',
    '    const val REGISTRATION_RESULT = "single_scanner_registration_result"\n',
)
replace_once(
    content_path,
    "            TextButton(onClick = onBack) { Text(stringResource(R.string.common_back)) }\n",
    '''            TextButton(
                onClick = onBack,
                enabled = !state.registrationInProgress,
            ) {
                Text(stringResource(R.string.common_back))
            }
''',
)
replace_once(
    content_path,
    '''    if (state.processing) {
        AlertDialog(
            modifier = Modifier.testTag(SinglePageScannerTestTags.PROCESSING),
            onDismissRequest = {},
            title = { Text(stringResource(R.string.single_scanner_processing)) },
            text = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator()
                    Text(stringResource(R.string.single_scanner_review_explanation))
                }
            },
            confirmButton = {
                TextButton(onClick = onCancelProcessing) {
                    Text(stringResource(R.string.single_scanner_cancel_processing))
                }
            },
        )
    }
''',
    '''    if (state.processing || state.registrationInProgress) {
        AlertDialog(
            modifier = Modifier.testTag(SinglePageScannerTestTags.PROCESSING),
            onDismissRequest = {},
            title = {
                Text(
                    stringResource(
                        if (state.registrationInProgress) {
                            R.string.single_scanner_registering
                        } else {
                            R.string.single_scanner_processing
                        },
                    ),
                )
            },
            text = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator()
                    Text(
                        stringResource(
                            if (state.registrationInProgress) {
                                R.string.single_scanner_registering_explanation
                            } else {
                                R.string.single_scanner_review_explanation
                            },
                        ),
                    )
                }
            },
            confirmButton = {
                if (state.processing) {
                    TextButton(onClick = onCancelProcessing) {
                        Text(stringResource(R.string.single_scanner_cancel_processing))
                    }
                }
            },
        )
    }
''',
)
replace_once(
    content_path,
    '''        if (state.approvedForRegistration) {
            Card(
                modifier = Modifier.fillMaxWidth().testTag(SinglePageScannerTestTags.APPROVED_NOT_SAVED),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        stringResource(R.string.single_scanner_approved),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(stringResource(R.string.single_scanner_not_saved))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onApprove,
                enabled = state.canApprove && !state.approvedForRegistration,
            ) {
                Text(stringResource(R.string.single_scanner_accept))
            }
            OutlinedButton(onClick = onRetake) {
                Text(stringResource(R.string.single_scanner_retake))
            }
''',
    '''        state.registeredScan?.let { registered ->
            Card(
                modifier = Modifier.fillMaxWidth().testTag(SinglePageScannerTestTags.REGISTRATION_RESULT),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        stringResource(R.string.single_scanner_saved),
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(stringResource(R.string.single_scanner_saved_scan_id, registered.scanId))
                    Text(
                        stringResource(
                            R.string.single_scanner_saved_status,
                            registered.qualityStatus.name,
                        ),
                    )
                    registered.warnings.forEach { warning ->
                        Text(stringResource(R.string.single_scanner_detail_warning, warning.name))
                    }
                    registered.requiredActions.forEach { action ->
                        Text(stringResource(R.string.single_scanner_required_action, action.name))
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (state.registeredScan == null) {
                Button(
                    onClick = onApprove,
                    enabled = state.canApprove,
                ) {
                    Text(stringResource(R.string.single_scanner_save_scan))
                }
            }
            OutlinedButton(
                onClick = onRetake,
                enabled = !state.registrationInProgress,
            ) {
                Text(
                    stringResource(
                        if (state.registeredScan == null) {
                            R.string.single_scanner_retake
                        } else {
                            R.string.single_scanner_scan_another
                        },
                    ),
                )
            }
''',
)
replace_once(
    content_path,
    '''                    Text(stringResource(R.string.single_scanner_detail_pipeline, it.pipelineVersion))
                    Text(stringResource(R.string.single_scanner_not_saved))
                    it.identityWarning?.let { warning ->
''',
    '''                    Text(stringResource(R.string.single_scanner_detail_pipeline, it.pipelineVersion))
                    val registered = state.registeredScan
                    if (registered == null) {
                        Text(stringResource(R.string.single_scanner_awaiting_registration))
                    } else {
                        Text(stringResource(R.string.single_scanner_saved_scan_id, registered.scanId))
                        Text(
                            stringResource(
                                R.string.single_scanner_saved_status,
                                registered.qualityStatus.name,
                            ),
                        )
                    }
                    it.identityWarning?.let { warning ->
''',
)

# User-facing copy must claim success only after the Rust result exists.
strings_path = "apps/android/app/src/main/res/values/strings.xml"
replace_once(
    strings_path,
    '''    <string name="single_scanner_accept">Approve</string>
    <string name="single_scanner_retake">Retake</string>
    <string name="single_scanner_approved">Approved for registration — not saved yet</string>
    <string name="single_scanner_not_saved">Milestone 9 durable registration is not implemented. This screen never claims the page is saved.</string>
''',
    '''    <string name="single_scanner_save_scan">Save scan</string>
    <string name="single_scanner_retake">Retake</string>
    <string name="single_scanner_scan_another">Scan another page</string>
    <string name="single_scanner_registering">Saving scan durably in Rust…</string>
    <string name="single_scanner_registering_explanation">Rust is revalidating identity and markers, committing immutable image assets, and updating the library transactionally.</string>
    <string name="single_scanner_saved">Scan saved</string>
    <string name="single_scanner_saved_scan_id">Scan ID: %1$s</string>
    <string name="single_scanner_saved_status">Status: %1$s</string>
    <string name="single_scanner_required_action">Required action: %1$s</string>
    <string name="single_scanner_awaiting_registration">This reviewed capture has not been saved yet.</string>
''',
)

# Resolve all committed asset paths before the database transaction so a successful transaction
# cannot be followed by a fallible path-resolution error reported to the caller.
core_path = "crates/a2d-core/src/milestone9.rs"
replace_once(
    core_path,
    '''        let (original, corrected, ocr, thumbnail) = asset_result.map_err(|error| {
            error
                .with_detail("asset_commit_journal", journal_path.clone())
                .with_detail("staging_path", staged.canonical_path.to_string_lossy())
        })?;

        let scan = Scan::new(
''',
    '''        let (original, corrected, ocr, thumbnail) = asset_result.map_err(|error| {
            error
                .with_detail("asset_commit_journal", journal_path.clone())
                .with_detail("staging_path", staged.canonical_path.to_string_lossy())
        })?;
        let resolve_path = |asset: &Asset| {
            self.resolve_asset_path(asset).map_err(|error| {
                error
                    .with_detail("asset_commit_journal", journal_path.clone())
                    .with_detail("staging_path", staged.canonical_path.to_string_lossy())
            })
        };
        let original_path = resolve_path(&original)?;
        let corrected_path = resolve_path(&corrected)?;
        let ocr_path = resolve_path(&ocr)?;
        let thumbnail_path = resolve_path(&thumbnail)?;

        let scan = Scan::new(
''',
)
replace_once(
    core_path,
    '''            original_path: self.resolve_asset_path(&original)?,
            corrected_path: self.resolve_asset_path(&corrected)?,
            ocr_path: self.resolve_asset_path(&ocr)?,
            thumbnail_path: self.resolve_asset_path(&thumbnail)?,
''',
    '''            original_path,
            corrected_path,
            ocr_path,
            thumbnail_path,
''',
)

# State-machine test for the durable review completion boundary.
test_path = "apps/android/app/src/test/kotlin/com/a2d/notebook/feature/scanner/capture/AutoCaptureStateMachineTest.kt"
insert_before_once(
    test_path,
    "    @Test\n    fun staleProcessingCallbackCannotMutateNewGeneration() {\n",
    '''    @Test
    fun durableReviewRegistrationTransitionsToAcceptedOnlyForMatchingToken() {
        val machine = startedMachine()
        val request = triggerAutoCapture(machine)
        machine.captureSucceeded(request.token, CapturedImage("/staging/page.jpg"))
        machine.processingCompleted(
            request.token,
            AutoCaptureProcessingOutcome.NeedsReview("explicit user approval required"),
        )

        val accepted = machine.reviewRegistrationCompleted(request.token, "scan-durable")
        assertEquals(
            AutoCapturePhase.Accepted(request, "scan-durable"),
            accepted.snapshot.phase,
        )

        val stale = machine.reviewRegistrationCompleted(request.token, "scan-second")
        assertEquals(
            AutoCapturePhase.Accepted(request, "scan-durable"),
            stale.snapshot.phase,
        )
        assertEquals(
            "reviewRegistrationCompleted",
            stale.effects.filterIsInstance<AutoCaptureEffect.StaleCallbackIgnored>().single().callback,
        )
    }

''',
)

# Pure request conversion tests.
request_test = ROOT / "apps/android/app/src/test/kotlin/com/a2d/notebook/feature/scanner/singlepage/ScanRegistrationRequestTest.kt"
request_test.parent.mkdir(parents=True, exist_ok=True)
request_test.write_text(
    '''package com.a2d.notebook.feature.scanner.singlepage

import com.a2d.notebook.rustbridge.AnalyzedPageMarker
import com.a2d.notebook.rustbridge.AnalyzedPagePoint
import com.a2d.notebook.rustbridge.EncodedPageRotation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import uniffi.a2d_ffi.RegistrationImageRotation

class ScanRegistrationRequestTest {
    @Test
    fun rotationsMapWithoutChangingMeaning() {
        assertEquals(
            RegistrationImageRotation.DEGREES0,
            EncodedPageRotation.DEGREES_0.toRegistrationImageRotation(),
        )
        assertEquals(
            RegistrationImageRotation.DEGREES90,
            EncodedPageRotation.DEGREES_90.toRegistrationImageRotation(),
        )
        assertEquals(
            RegistrationImageRotation.DEGREES180,
            EncodedPageRotation.DEGREES_180.toRegistrationImageRotation(),
        )
        assertEquals(
            RegistrationImageRotation.DEGREES270,
            EncodedPageRotation.DEGREES_270.toRegistrationImageRotation(),
        )
    }

    @Test
    fun markerConversionRequiresExactlyFourSemanticRoles() {
        val markers = listOf("TL", "TR", "BR", "BL").mapIndexed(::marker)
        val converted = markers.toRegistrationMarkers()
        assertEquals(listOf("TL", "TR", "BR", "BL"), converted.map { it.role })
        assertEquals(listOf(0u, 1u, 2u, 3u), converted.map { it.id })

        val invalid = runCatching { markers.dropLast(1).toRegistrationMarkers() }.exceptionOrNull()
        assertTrue(invalid is IllegalArgumentException)
    }

    @Test
    fun warningConversionIsStableAndRejectsMissingMarkers() {
        assertEquals(
            listOf("LOW_FOCUS", "TOO_DARK"),
            setOf(CapturePolicyWarning.TOO_DARK, CapturePolicyWarning.LOW_FOCUS)
                .toRegistrationWarningCodes(),
        )
        val invalid =
            runCatching {
                setOf(CapturePolicyWarning.MISSING_MARKERS).toRegistrationWarningCodes()
            }.exceptionOrNull()
        assertTrue(invalid is IllegalArgumentException)
    }

    private fun marker(index: Int, role: String): AnalyzedPageMarker =
        AnalyzedPageMarker(
            role = role,
            family = "tagStandard41h12",
            id = index.toLong(),
            hammingErrors = 0,
            decisionMargin = 50.0,
            center = AnalyzedPagePoint(10.0, 10.0),
            corners =
                listOf(
                    AnalyzedPagePoint(0.0, 0.0),
                    AnalyzedPagePoint(1.0, 0.0),
                    AnalyzedPagePoint(1.0, 1.0),
                    AnalyzedPagePoint(0.0, 1.0),
                ),
        )
}
''',
    encoding="utf-8",
)

# Fail loudly if old placeholder state survived any replacement.
for path in (state_path, vm_path, content_path, strings_path):
    text = read(path)
    if "approvedForRegistration" in text or "Milestone 9 durable registration is not implemented" in text:
        raise RuntimeError(f"{path}: obsolete not-saved placeholder remains")

print("Milestone 9 Android durable registration patch applied")
